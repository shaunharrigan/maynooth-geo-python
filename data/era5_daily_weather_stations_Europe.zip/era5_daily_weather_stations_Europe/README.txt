GY674 / GY675
ERA5 Daily Weather Data – Five European Cities
================================================

CONTENTS

This folder contains five CSV files of daily weather data for:
- Dublin, Ireland
- Bergen, Norway
- Madrid, Spain
- Helsinki, Finland
- Athens, Greece

DATA SOURCE

ERA5 climate reanalysis, produced by the European Centre for Medium-Range Weather Forecasts (ECMWF) for the Copernicus Climate Change Service (C3S).

Data accessed via the Open-Meteo Historical Weather API:
https://open-meteo.com/en/docs/historical-weather-api

Period: 1 January 1991 – 31 December 2025
Temporal resolution: Daily (12,784 observations per location)

VARIABLES

Date                    Date (DD/MM/YYYY)
temperature_mean_DegC   Daily mean 2 m air temperature (°C)
temperature_max_DegC    Daily maximum 2 m air temperature (°C)
temperature_min_DegC    Daily minimum 2 m air temperature (°C)
precipitation_mm        Daily total precipitation (mm)

IMPORTANT NOTES

- These are ERA5 reanalysis estimates, not direct weather station observations.
- Each CSV represents an ERA5 grid cell near the named city.
- Daily values are calculated using UTC (GMT).
- All five datasets have the same structure, allowing comparisons between locations.